#pragma once

#include <quda_internal.h>
// if not using heterogeneous atomics use the generic variant
#include "../generic/reduce_helper.h"
