#include <quda.h>

int main()
{
  initQuda(0);
  endQuda();
}
